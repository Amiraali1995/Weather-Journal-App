const current_Date = new Date().toDateString();
//URLs and API
const weatherbaseURL = 'http://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = '&appid=d00da02df202cf9e7c6108851ccd2ce1';
const serverUrl = "http://127.0.0.1:8000"

const errors = document.getElementById("error");

const generateData = () => { 

    const ConutryZipCode = document.getElementById("zip").value;
  const userFeel = document.getElementById("feelings").value;

  getWeatherData(ConutryZipCode).then((data) => {
    if (data) {
      const {
        main: { cityTemperature },
        name: NameOfCity,
        weather: [{ description }],
      } = data;

      const info = {
        current_Date,
        NameOfCity,
        cityTemperature: Math.round(cityTemperature), 
        description,
        userFeel,
      };

      postData(serverUrl + "/add", info);

      updatingUI();
      document.getElementById('entry').style.opacity = 1;
    }
  });
};


document.getElementById("generate").addEventListener("click", generateData);

const getWeatherData = async (zip) => {
  try {
    const res = await fetch(weatherbaseURL + zip + apiKey);
    const data = await res.json();

    if (data.cod != 200) {
      errors.innerHTML = data.message;
      setTimeout(_=> errors.innerHTML = '', 2000)
      throw `${data.message}`;
    }

    return data;
  } catch (error) {
    console.log(error);
  }
};

const postData = async (url = "", info = {}) => {
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(info),
  });

  try {
    const newData = await res.json();
    console.log(`You just saved`, newData);
    return newData;
  } catch (error) {
    console.log(error);
  }
};

const updatingUI = async () => {
  const res = await fetch(serverUrl + "/all");
  try {
    const savedData = await res.json();

    document.getElementById("date").innerHTML = savedData.current_Date;
    document.getElementById("NameOfCity").innerHTML = savedData.NameOfCity;
    document.getElementById("cityTemperature").innerHTML = savedData.cityTemperature ;
    document.getElementById("description").innerHTML = savedData.description;
    document.getElementById("content").innerHTML = savedData.userFeel;
  } catch (error) {
    console.log(error);
  }
};