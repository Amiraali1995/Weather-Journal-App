let projectData = {};
// Setup empty JS object to act as endpoint for all routes
// Express to run server and routes

const express = require("express");

// Start up an instance of app
const app = express();

/* Dependencies */
/* Middleware*/

const bodyparser = require("body-parser");
app.use(bodyparser.urlencoded({extended:false}));
app.use(bodyparser.json());

//Here we are configuring express to use body-parser as middle-ware.
// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());

// Initialize the main project folder

app.use(express.static("website"));

// Callback to debug

// Initialize all route with a callback function

// Callback function to complete GET '/all'
const getAllData = (req, res) => res.status(200).send(projectData);
app.get("/all", getAllData);
// Post Route
const addData = (req, res) => {
    projectData = req.body;
    console.log(projectData);
    res.status(200).send(projectData);
}

app.post("/add", addData);
// Setup Server
const port = 8000;
const hname = "127.0.0.1";
// function to test the server
const listening = () =>
console.log(`Server running at http://${hname}:${port}/`);

//spin up the server
app.listen(port,listening);